package com.example.blehomeapp.utils;

import android.content.Context;
import com.example.blehomeapp.R;

public class LvBleDeviceLine {
    private String deviceName;
    private String deviceAddr;

    public LvBleDeviceLine(Context context, String deviceName, String deviceAddr) {

        if (deviceName !=null && deviceName.length()>0) {
            this.deviceName = deviceName;
        } else {
            this.deviceName = context.getString(R.string.unknown_device);
        }
        this.deviceAddr = deviceAddr;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public String getDeviceAddr() {
        return deviceAddr;
    }

    public void setDeviceAddr(String deviceAddr) {
        this.deviceAddr = deviceAddr;
    }
}
