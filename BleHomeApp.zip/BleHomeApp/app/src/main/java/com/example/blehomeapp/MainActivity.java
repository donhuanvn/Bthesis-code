package com.example.blehomeapp;

import android.content.ComponentName;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.IBinder;
import android.os.Trace;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

import com.example.blehomeapp.services.BleForwardingService;
import com.example.blehomeapp.services.BluetoothLeService;
import com.example.blehomeapp.utils.LvMainLine;
import com.example.blehomeapp.utils.LvMainAdapter;

import static java.lang.Thread.sleep;

public class MainActivity extends AppCompatActivity {

    private final static String TAG = "MAIN_HOMEAPP";


    ListView lvMain;
    ArrayList<LvMainLine> lvMainArray;
    LvMainAdapter lvMainAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //--------------------show Welcome Screen before start app----------------------------------
        Intent intent = new Intent(this, SpflashActivity.class);
        startActivity(intent);

        // Use this check to determine whether BLE is supported on the device.  Then you can
        // selectively disable BLE-related features.
        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
            Toast.makeText(this, R.string.ble_not_supported, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        ListViewMainInitial();
        InitializeServices();

        lvMain.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent;
                switch (position) {
                    case 0:
                        intent = new Intent(MainActivity.this, LightControlActivity.class);
                        startActivity(intent);
                        break;
                    case 1:
                        intent = new Intent(MainActivity.this, BleConnectionActivity.class);
                        startActivity(intent);
                        break;
                    case 2:
                        intent = new Intent(MainActivity.this, BleForwardingActivity.class);
                        startActivity(intent);
                        break;

                        default:
                            break;
                }
                overridePendingTransition(R.anim.anim_intent_enter,R.anim.anim_intent_exit);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unbindService(mBleServiceConnection);
        unbindService(mBleForwServiceConnection);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        AlertDialog alertDialog;

        switch (item.getItemId()) {
            case R.id.main_menu_item_info:
                builder.setTitle(R.string.main_menu_item_info);
                builder.setMessage(R.string.main_alertdialog_info_msg);
                builder.setCancelable(false);
                builder.setPositiveButton(R.string.main_alertdialog_button,
                        new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                builder.setNegativeButton("", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                alertDialog = builder.create();
                alertDialog.show();
                break;

            case R.id.main_menu_item_notes:
                builder.setTitle(R.string.main_menu_item_notes);
                builder.setMessage(R.string.main_alertdialog_note_msg);
                builder.setCancelable(false);
                builder.setPositiveButton(R.string.main_alertdialog_button,
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                builder.setNegativeButton("", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                alertDialog = builder.create();
                alertDialog.show();
                break;

            case R.id.main_menu_item_intruc:
                builder.setTitle(R.string.main_menu_item_instruction);
                builder.setMessage(R.string.main_alertdialog_intruc_msg);
                builder.setCancelable(false);
                builder.setPositiveButton(R.string.main_alertdialog_button,
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                builder.setNegativeButton("", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                alertDialog = builder.create();
                alertDialog.show();
                break;
        }

        return super.onOptionsItemSelected(item);
    }

    private void ListViewMainInitial() {
        lvMain = (ListView) findViewById(R.id.list_view_main);
        lvMainArray = new ArrayList<>();
        lvMainArray.add(new LvMainLine(getString(R.string.lv_main_lighting_control_panel),
                                        getString(R.string.lv_main_lc_panel_descriptor),
                                        R.drawable.lv_main_icon1));
        lvMainArray.add(new LvMainLine(getString(R.string.lv_main_ble_conn_setup),
                                        getString(R.string.lv_main_ble_conn_descriptor),
                                        R.drawable.lv_main_icon2));
        lvMainArray.add(new LvMainLine(getString(R.string.lv_main_ble_forwarding_setup),
                                        getString(R.string.lv_main_ble_forw_descriptor),
                                        R.drawable.lv_main_icon3));

        lvMainAdapter = new LvMainAdapter(this, R.layout.list_view_main_line, lvMainArray);
        lvMain.setAdapter(lvMainAdapter);
    }

    private void InitializeServices() {
        Intent intentBle = new Intent(MainActivity.this, BluetoothLeService.class);
        bindService(intentBle, mBleServiceConnection, BIND_AUTO_CREATE);

        Intent intentBleForw = new Intent(MainActivity.this, BleForwardingService.class);
        bindService(intentBleForw, mBleForwServiceConnection, BIND_AUTO_CREATE);
    }

    //----------------------------------------------------------------------------------------------
    //-----------------------------Initialize Services----------------------------------------------
    private ServiceConnection mBleServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            Log.d(TAG, "BluetoothLeService Started & Connected!");
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            Log.d(TAG, "BluetoothLeService disconnected!");
        }
    };

    private ServiceConnection mBleForwServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            Log.d(TAG, "BleForwardingService Started & Connected!");
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            Log.d(TAG, "BleForwardingService disconnected!");
        }
    };
}
