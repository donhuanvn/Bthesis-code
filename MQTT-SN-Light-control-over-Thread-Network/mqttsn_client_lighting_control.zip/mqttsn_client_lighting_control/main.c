/** @file
 *
 * @brief MQTT-SN lightting control based-on OpenThread.
 *
 * @details This example demonstrates an MQTT-SN client application that enables to 
 * 			publish/subscribe data over Thread Network via MQTT-SN messages.
 *
 */

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include "app_scheduler.h"
#include "app_timer.h"
#include "bsp_thread.h"

#include "nrf_drv_twi.h"
#include "nrf_delay.h"
#include "isl29023-sensor-SDKv15.h"

#include "nrf_log.h"
#include "nrf_log_ctrl.h"
#include "nrf_log_default_backends.h"

#include "mqttsn_client.h"
#include "thread_utils.h"
#include <openthread/thread.h>
#include <openthread/platform/radio.h>

#define LAMP_X						"lamp_2"

#define SEARCH_GATEWAY_TIMEOUT 		5                                            /**< MQTT-SN Gateway discovery procedure timeout in [s]. */
#define SCHED_QUEUE_SIZE       		32                                           /**< Maximum number of events in the scheduler queue. */
#define SCHED_EVENT_DATA_SIZE  		APP_TIMER_SCHED_EVENT_DATA_SIZE              /**< Maximum app_scheduler event size. */

#define LAMP_OFF					0
#define LAMP_ON						1
#define LAMP_INVERT					2
#define LIGHT_THRESHOLD				60
#define AUTO_FUNC_INTERVAL_DEFAULT	10

typedef struct mqttsn_topic_state {
		bool registered;
		bool subscribed;
} mqttsn_topic_state;

APP_TIMER_DEF(m_auto_func_timer_id);
static uint16_t m_light_intensity;
static uint8_t 	m_auto_func_interval 			= AUTO_FUNC_INTERVAL_DEFAULT;

static uint8_t				m_txpower			= 0;						/**< Default txpower is 0 dBm*/
static mqttsn_client_t      m_client;                                       /**< An MQTT-SN client instance. */
static mqttsn_remote_t      m_gateway_addr;                                 /**< A gateway address. */
static uint8_t              m_gateway_id;                                   /**< A gateway ID. */
static mqttsn_connect_opt_t m_connect_opt;                                  /**< Connect options for the MQTT-SN client. */
static char                 m_client_id[]      	= "HAS_"LAMP_X;      				/**< The MQTT-SN Client's ID. */
static uint16_t             m_msg_id           	= 0;                         /**< Message ID thrown with MQTTSN_EVENT_TIMEOUT. */

static uint8_t				m_topic_registering	= 0;
static char                 m_topic_1_name[]	= "HAS_resources/"LAMP_X"/control";
/**< This topic is to receive user's commands */
static char                 m_topic_2_name[]   	= "HAS_resources/"LAMP_X"/log";
/**< This topic is to notify user know what happen */
static char					m_topic_3_name[]	= "HAS_resources/"LAMP_X"/info";
/**< This topic is to publish lamp's current information include: light intensity, lamp state  */
static mqttsn_topic_t       m_topic_1          	=                            
{
    .p_topic_name = (unsigned char *)m_topic_1_name,
    .topic_id     = 0,
};
static mqttsn_topic_t       m_topic_2          	=                            
{
    .p_topic_name = (unsigned char *)m_topic_2_name,
    .topic_id     = 0,
};
static mqttsn_topic_t       m_topic_3          	=                            
{
    .p_topic_name = (unsigned char *)m_topic_3_name,
    .topic_id     = 0,
};
/*
static mqttsn_topic_state	m_topic_1_state		=
{
	.registered = false,
	.subscribed = false,
};

static mqttsn_topic_state	m_topic_2_state		=
{
	.registered = false,
	.subscribed = false,
};

static mqttsn_topic_state	m_topic_3_state		=
{
	.registered = false,
	.subscribed = false,
};*/

/***************************************************************************************************
 * @section function prototypes
 **************************************************************************************************/
static void topic_3_publish(char msg[]);
void lamp_connect_gateway(uint8_t process);

/***************************************************************************************************
 * @section string processing functions 
 **************************************************************************************************/
/**@brief reverse string s
*/
void strrev(char s[])
{
	char c;
	int l = strlen(s);
	for (int i=0; i<l/2; i++)
	{
		c = s[i];
		s[i] = s[l-1-i];
		s[l-1-i] = c;
	}
}
/**@brief  convert n to characters in s
*/
void ltoa(long int n, char s[])
{
    int i;
	long int sign;
 
    if ((sign = n) < 0)  /* record sign */
        n = -n;          /* make n positive */
    i = 0;
    do {       /* generate digits in reverse order */
		s[i++] = n % 10 + '0';   /* get next digit */
    } while ((n /= 10) > 0);     /* delete it */
    if (sign < 0)
        s[i++] = '-';
    s[i] = '\0';
	strrev(s);
}
 
/***************************************************************************************************
 * @section Lamp Control
 **************************************************************************************************/
/**
 * @brief forcing lamp state.
 * @param[in] state State of lamp, possible value:
 * 					LAMP_OFF
 * 					LAMP_ON
 * 					LAMP_INVERT
 */
static void lamp_force(uint8_t state)
{
	if (state == LAMP_ON)
	{
		LEDS_ON(BSP_LED_1_MASK);
	} else if (state == LAMP_INVERT) 
	{
		LEDS_INVERT(BSP_LED_1_MASK);
	} else {
		LEDS_OFF(BSP_LED_1_MASK);
	}
}
/**
 * @brief Function for controlling lamp automatically.
 * @details read light intensity from ISL29023 sensor. Control lamp based on light intensity and
 *			LIGHT_THRESHOLD. State of lamp and light intensity will be converted to a merged string. 
 *			Finally, publish this string to topic info (topic 3).
 * @param[in] p_context pointer of an app timer.
 */
void lamp_auto(void * p_context)
{
	char light_intensity[10];
	char publish_str[20];
	
	memset(light_intensity, NULL, sizeof(light_intensity));
	memset(publish_str, NULL, sizeof(publish_str));
	
	isl29023_read_lux(&m_light_intensity);//**Dangerous!**//

	if (m_light_intensity>=LIGHT_THRESHOLD)
	{
		lamp_force(LAMP_OFF);
		strcat(publish_str, "off  ");	//add state of lamp to string for publish;
	} else {
		lamp_force(LAMP_ON);
		strcat(publish_str, "on  ");	//add state of lamp to string for publish;
	}
	
	ltoa(m_light_intensity, light_intensity);	//convert long int to string;
	strcat(light_intensity, " lux");	//add uint of light intensity;
	strcat(publish_str,light_intensity);	//add light information to string for publish;
	
	topic_3_publish(publish_str);	//publish data to topic 3
}
/***************************************************************************************************
 * @section MQTT-SN topic control (topic 1)
 **************************************************************************************************/
/**
 * @brief Function for disconnecting to MQTT-SN Gateway.
 */
void control_disconnect(void)
{
	uint32_t err_code;

	err_code = mqttsn_client_disconnect(&m_client);
	if (err_code != NRF_SUCCESS)
	{
		NRF_LOG_ERROR("DISCONNECT message could not be sent. Error: 0x%x\r\n", err_code);
	}
}
/**
 * @brief Function for processing "auto" command from topic control (topic 1).
 * @details recognize the input command. Control auto function application timer base on 
 *			regcognized information. Auto function timer interval is not greater than 30s
 *			and not lower then 3s.
 * @param[in] p_string pointer to string command: "<on/off> <interval>"
 *			  str_len  length of string command
 */
void control_auto(char * p_string, uint16_t str_len) 
{
	char p_string_t[str_len];
	char * saveptr;
	uint8_t interval;
	uint32_t err_code;

	memset(p_string_t, 0, sizeof(p_string_t));
	strncpy(p_string_t, p_string, str_len);
	
	strtok_r(p_string_t, " ", &saveptr);
		
	if (strcmp(p_string_t, "off") == 0)
	{
		err_code = app_timer_stop(m_auto_func_timer_id);
		APP_ERROR_CHECK(err_code);
		NRF_LOG_INFO("Control command: auto function is stopped!");
	} else if (strcmp(p_string_t, "on") == 0)
	{
		interval = atol(saveptr);
		if ((interval<3) || (interval>30))
		{
			m_auto_func_interval = AUTO_FUNC_INTERVAL_DEFAULT;
			NRF_LOG_INFO("Control command: 3<=interval<=30 (s)");
			NRF_LOG_INFO("Timer will start with default interval.");
		} else 
		{
			m_auto_func_interval = interval;
		}
		err_code = app_timer_stop(m_auto_func_timer_id);	//a precaution when "auto on <interval>" command is sent continuously.
		APP_ERROR_CHECK(err_code);
		err_code = app_timer_start(m_auto_func_timer_id, APP_TIMER_TICKS(m_auto_func_interval*1000), NULL);
		APP_ERROR_CHECK(err_code);
		NRF_LOG_INFO("Control command: auto function is started with %d (s) interval", m_auto_func_interval);		
	} else {
		NRF_LOG_INFO("Control command: error!");
	}
}
/**
 * @brief Function for processing "force" command from topic control (topic 1).
 * @details recognize the input command. Turn on/off lamp base on recognized information.
 * @param[in] p_string pointer to string command: "<on/off>"
 */
void control_force(char * p_string)	//<on/off>
{
	if (strncmp(p_string, "on", 2)==0)
	{
		lamp_force(LAMP_ON);
	} else if (strncmp(p_string, "off", 3)==0)
	{
		lamp_force(LAMP_OFF);
	} else {
		NRF_LOG_INFO("Control command: error!");
	}
}
/**
 * @brief Function for resolving command from topic control (topic 1).
 * @details recognize first word from the input command.
 * @param[in] p_string pointer to string command: "<on/off>"
 */
static void recognize_control_command(uint8_t * p_string, uint16_t str_len)
{
	char p_string_t[str_len+1];
	char * saveptr;
	
	memset(p_string_t, NULL, sizeof(p_string_t));
	strncpy(p_string_t, (char *)p_string,str_len);
	strtok_r(p_string_t, " ", &saveptr);
	
	if (strcmp(p_string_t,"disconnect")==0)
	{
		control_disconnect();
		return;
	}
	if (strcmp(p_string_t, "force")==0)
	{
		control_force(saveptr);
		return;
	}
	if (strcmp(p_string_t, "auto")==0)
	{
		control_auto(saveptr, str_len-5);	// str_len-5: removed "auto "
		return;
	}
}
/***************************************************************************************************
 * @section MQTT-SN
 **************************************************************************************************/
/**@brief Initializes MQTT-SN client's connection options.
 */
static void connect_opt_init(void)
{
    m_connect_opt.alive_duration = MQTTSN_DEFAULT_ALIVE_DURATION,
    m_connect_opt.clean_session  = MQTTSN_DEFAULT_CLEAN_SESSION_FLAG,
    m_connect_opt.will_flag      = MQTTSN_DEFAULT_WILL_FLAG,
    m_connect_opt.client_id_len  = strlen(m_client_id),

    memcpy(m_connect_opt.p_client_id, (unsigned char *)m_client_id, m_connect_opt.client_id_len);
}


/**@brief Processes GWINFO message from a gateway.
 *
 * @details This function updates MQTT-SN Gateway information.
 *
 * @param[in]    p_event  Pointer to MQTT-SN event.
 */
static void gateway_info_callback(mqttsn_event_t * p_event)
{
    m_gateway_addr = *(p_event->event_data.connected.p_gateway_addr);
    m_gateway_id   = p_event->event_data.connected.gateway_id;
}


/**@brief Processes CONNACK message from a gateway.
 *
 * @details This function launches the topic registration procedure if necessary.
 */
static void connected_callback(void)
{
		LEDS_ON(BSP_LED_3_MASK);
}
/**@brief Processes DISCONNECT message from a gateway. */
static void disconnected_callback(void)
{
		LEDS_OFF(BSP_LED_3_MASK);
}


/**@brief Processes REGACK message from a gateway.
 *
 * @param[in] p_event Pointer to MQTT-SN event.
 */
static void regack_callback(mqttsn_event_t * p_event)
{
	switch (m_topic_registering)
	{
		case 1:
		{
			m_topic_1.topic_id = p_event->event_data.registered.packet.topic.topic_id;
			NRF_LOG_INFO("MQTT-SN event: Topic 1 has been registered with ID: %d.\r\n",
					 p_event->event_data.registered.packet.topic.topic_id);
			lamp_connect_gateway(3);
			break;
		}
		case 2:
		{
			m_topic_2.topic_id = p_event->event_data.registered.packet.topic.topic_id;
			NRF_LOG_INFO("MQTT-SN event: Topic 2 has been registered with ID: %d.\r\n",
					 p_event->event_data.registered.packet.topic.topic_id);
			lamp_connect_gateway(4);
			break;
		}
		case 3:
		{
			m_topic_3.topic_id = p_event->event_data.registered.packet.topic.topic_id;
			NRF_LOG_INFO("MQTT-SN event: Topic 3 has been registered with ID: %d.\r\n",
					 p_event->event_data.registered.packet.topic.topic_id);
			lamp_connect_gateway(5);
			break;
		}
		default:
			break;
	}
}


/**@brief Processes retransmission limit reached event. */
static void timeout_callback(mqttsn_event_t * p_event)
{
    NRF_LOG_INFO("MQTT-SN event: Timed-out message: %d. Message ID: %d.\r\n",
                  p_event->event_data.error.msg_type,
                  p_event->event_data.error.msg_id);
}


/**@brief Processes results of gateway discovery procedure. */
static void searchgw_timeout_callback(mqttsn_event_t * p_event)
{
    NRF_LOG_INFO("MQTT-SN event: Gateway discovery result: 0x%x.\r\n", p_event->event_data.discovery);
}


/**@brief Processes data published by a broker.
 *
 * @details This function recognize control command.
 */
static void received_callback(mqttsn_event_t * p_event)
{
	if (p_event->event_data.published.packet.topic.topic_id == m_topic_1.topic_id)
    {
        NRF_LOG_INFO("MQTT-SN event: Content to subscribed topic received.\r\n");
        recognize_control_command(p_event->event_data.published.p_payload,
						p_event->event_data.published.payload_len);
    }
    else
    {
        NRF_LOG_INFO("MQTT-SN event: Content to unsubscribed topic received. Dropping packet.\r\n");
    }
}
/**@brief Publish a message to topic 3
 */
static void topic_3_publish(char pub_msg[])
{
	uint32_t err_code;
	err_code = mqttsn_client_publish(&m_client, m_topic_3.topic_id,(uint8_t *) pub_msg,
										strlen(pub_msg), &m_msg_id);
    if (err_code != NRF_SUCCESS)
    {
		app_timer_stop(m_auto_func_timer_id);
		NRF_LOG_INFO("Error was happen! app_timer has been stopped!");
        NRF_LOG_ERROR("PUBLISH message could not be sent. Error code: 0x%x\r\n", err_code);
    }
}
/**@brief Function for handling MQTT-SN events. */
void mqttsn_evt_handler(mqttsn_client_t * p_client, mqttsn_event_t * p_event)
{
    switch(p_event->event_id)
    {
        case MQTTSN_EVENT_GATEWAY_FOUND:
            NRF_LOG_INFO("MQTT-SN event: Client has found an active gateway.\r\n");
            gateway_info_callback(p_event);
			lamp_connect_gateway(1);
            break;

        case MQTTSN_EVENT_CONNECTED:
            NRF_LOG_INFO("MQTT-SN event: Client connected.\r\n");
            connected_callback();
			lamp_connect_gateway(2);
            break;

        case MQTTSN_EVENT_DISCONNECT_PERMIT:
            NRF_LOG_INFO("MQTT-SN event: Client disconnected.\r\n");
            disconnected_callback();
            break;

        case MQTTSN_EVENT_REGISTERED:
            NRF_LOG_INFO("MQTT-SN event: Client registered topic.\r\n");
            regack_callback(p_event);
            break;

        case MQTTSN_EVENT_PUBLISHED:
            NRF_LOG_INFO("MQTT-SN event: Client has successfully published content.\r\n");
            break;
				
        case MQTTSN_EVENT_SUBSCRIBED:
            NRF_LOG_INFO("MQTT-SN event: Client subscribed to topic.\r\n");
			lamp_connect_gateway(6);
            break;

        case MQTTSN_EVENT_UNSUBSCRIBED:
            NRF_LOG_INFO("MQTT-SN event: Client unsubscribed to topic.\r\n");
            break;

        case MQTTSN_EVENT_RECEIVED:
            NRF_LOG_INFO("MQTT-SN event: Client received content.\r\n");
            received_callback(p_event);
            break;
        case MQTTSN_EVENT_TIMEOUT:
            NRF_LOG_INFO("MQTT-SN event: Retransmission retries limit has been reached.\r\n");
            timeout_callback(p_event);
            break;

        case MQTTSN_EVENT_SEARCHGW_TIMEOUT:
            NRF_LOG_INFO("MQTT-SN event: Gateway discovery procedure has finished.\r\n");
            searchgw_timeout_callback(p_event);
            break;

        default:
            break;
    }
}

/***************************************************************************************************
 * @section State
 **************************************************************************************************/

static void state_changed_callback(uint32_t flags, void * p_context)
{
    NRF_LOG_INFO("State changed! Flags: 0x%08x Current role: %d\r\n",
                 flags, otThreadGetDeviceRole(p_context));
}

/***************************************************************************************************
 * @section Buttons
 **************************************************************************************************/
/**
 * @brief Function for connect lamp to MQTT-SN gateway.
 * @details search gateway->connect->register all topic->subscribe topic 1.
 * @param[in] process position of processing.
 */
void lamp_connect_gateway(uint8_t process)
{
	uint32_t err_code;
	switch (process)
	{
		case 0: //search gateway
		{	
			uint32_t err_code = mqttsn_client_search_gateway(&m_client, SEARCH_GATEWAY_TIMEOUT);
			if (err_code != NRF_SUCCESS)
			{
				NRF_LOG_ERROR("SEARCH GATEWAY message could not be sent. Error: 0x%x\r\n", err_code);
			}
			break;
		}
		case 1:	//found gateway, connect
		{	
			err_code = mqttsn_client_connect(&m_client, &m_gateway_addr, m_gateway_id, &m_connect_opt);
			if (err_code != NRF_SUCCESS)
			{
				NRF_LOG_ERROR("CONNECT message could not be sent. Error: 0x%x\r\n", err_code);
			}
			break;
		}		
		case 2: //connected, register topic 1
		{	
			m_topic_registering = 1;
			err_code = mqttsn_client_topic_register(&m_client,
													 m_topic_1.p_topic_name,
													 strlen(m_topic_1_name),
													 &m_msg_id);
			if (err_code != NRF_SUCCESS)
			{
				NRF_LOG_ERROR("REGISTER message for topic 1 could not be sent. Error code: 0x%x\r\n", err_code);
			}
			break;
		}
		case 3: //registered topic 1, register topic 2
		{
			m_topic_registering = 2;
			err_code = mqttsn_client_topic_register(&m_client,
													 m_topic_2.p_topic_name,
													 strlen(m_topic_2_name),
													 &m_msg_id);
			if (err_code != NRF_SUCCESS)
			{
				NRF_LOG_ERROR("REGISTER message for topic 2 could not be sent. Error code: 0x%x\r\n", err_code);
			}
			break;
		}
		case 4: //registered topic 1,  topic 2; register topic 3
		{
			m_topic_registering = 3;
			err_code = mqttsn_client_topic_register(&m_client,
													 m_topic_3.p_topic_name,
													 strlen(m_topic_3_name),
													 &m_msg_id);
			if (err_code != NRF_SUCCESS)
			{
				NRF_LOG_ERROR("REGISTER message for topic 3 could not be sent. Error code: 0x%x\r\n", err_code);
			}
			break;
		}
		case 5: //registered topic 1,  topic 2, topic 3; subcribe topic 1
		{
			err_code = mqttsn_client_subscribe(&m_client, m_topic_1.p_topic_name,
												strlen(m_topic_1_name), &m_msg_id);
			if (err_code != NRF_SUCCESS)
			{
				NRF_LOG_ERROR("SUBSCRIBE message for topic 1 could not be sent.\r\n");
			}
			break;
		}
		case 6:
			NRF_LOG_INFO("Congratulations! Connecting lamp to gateway was successful!");
		default:
			break;
	}	
}
static void bsp_event_handler(bsp_event_t event)
{
    if (otThreadGetDeviceRole(thread_ot_instance_get()) < OT_DEVICE_ROLE_CHILD )
    {
        (void)event;
        return;
    }
    
    switch (event)
    {
        case BSP_EVENT_KEY_0:
			if (mqttsn_client_state_get(&m_client) == MQTTSN_CLIENT_CONNECTED)
			{
                uint32_t err_code = mqttsn_client_disconnect(&m_client);
                if (err_code != NRF_SUCCESS)
                {
                    NRF_LOG_ERROR("DISCONNECT message could not be sent. Error: 0x%x\r\n", err_code);
                }
			} else {
				lamp_connect_gateway(0);
			}
			break;
        case BSP_EVENT_KEY_1:
			lamp_force(LAMP_INVERT);
			break;
		case BSP_EVENT_KEY_2:
		{	
			if (m_txpower<8) 
			{
				m_txpower += 4;
				if (m_txpower==8) LEDS_ON(BSP_LED_2_MASK);
				otPlatRadioSetTransmitPower(thread_ot_instance_get(), m_txpower);
			}
			break;
		}
		case BSP_EVENT_KEY_3:
		{	
			if (m_txpower>0) 
			{
				m_txpower -= 4;
				if (m_txpower<8) LEDS_OFF(BSP_LED_2_MASK);
				otPlatRadioSetTransmitPower(thread_ot_instance_get(), m_txpower);
			}
			break;
		}
        default:
            break;
    }
}

/***************************************************************************************************
 * @section Initialization
 **************************************************************************************************/

/**@brief Function for initializing the Application Timer Module.
 */
static void timer_init(void)
{
    uint32_t err_code = app_timer_init();
    APP_ERROR_CHECK(err_code);
}


/**@brief Function for initializing the LEDs.
 */
static void leds_init(void)
{
    LEDS_CONFIGURE(LEDS_MASK);
    LEDS_OFF(LEDS_MASK);
}


/**@brief Function for initializing the nrf log module.
 */
static void log_init(void)
{
    ret_code_t err_code = NRF_LOG_INIT(NULL);
    APP_ERROR_CHECK(err_code);

    NRF_LOG_DEFAULT_BACKENDS_INIT();
}
/**@brief Function for initializing Auto Function Timer.
 */
static void auto_func_timer_init(void)
{
	uint32_t err_code;
	err_code = app_timer_create(&m_auto_func_timer_id,
								APP_TIMER_MODE_REPEATED,
								lamp_auto);
    APP_ERROR_CHECK(err_code);
}
/**@brief Function for initializing the Thread Board Support Package.
 */
static void thread_bsp_init(void)
{
    uint32_t err_code;
    err_code = bsp_init(BSP_INIT_LEDS | BSP_INIT_BUTTONS, bsp_event_handler);
    APP_ERROR_CHECK(err_code);

    err_code = bsp_thread_init(thread_ot_instance_get());
    APP_ERROR_CHECK(err_code);
}


/**@brief Function for initializing the Thread Stack.
 */
static void thread_instance_init(void)
{
    thread_configuration_t thread_configuration =
    {
        .role              = RX_ON_WHEN_IDLE,
        .autocommissioning = true,
    };

    thread_init(&thread_configuration);
    thread_cli_init();
    thread_state_changed_callback_set(state_changed_callback);//** add state changed callback function to OT
}


/**@brief Function for initializing the MQTTSN client.
 */
static void mqttsn_init(void)
{
    uint32_t err_code = mqttsn_client_init(&m_client,
                                           MQTTSN_DEFAULT_CLIENT_PORT,
                                           mqttsn_evt_handler,
                                           thread_ot_instance_get());
    APP_ERROR_CHECK(err_code);

    connect_opt_init();
}


/**@brief Function for initializing scheduler module.
 */
static void scheduler_init(void)
{
    APP_SCHED_INIT(SCHED_EVENT_DATA_SIZE, SCHED_QUEUE_SIZE);
}

/***************************************************************************************************
 * @section Main
 **************************************************************************************************/
int main(int argc, char *argv[])
{
    log_init();
    scheduler_init();
    timer_init();
    leds_init();
	isl29023_twi_init();
	auto_func_timer_init();
	
    thread_instance_init();
    thread_bsp_init();
    mqttsn_init();
    while (true)
    {
        thread_process();
        app_sched_execute();

        if (NRF_LOG_PROCESS() == false)
        {
            thread_sleep();
        }
    }
}

/**
 *@}
 **/
