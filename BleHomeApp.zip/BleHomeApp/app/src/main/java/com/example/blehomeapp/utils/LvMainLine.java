package com.example.blehomeapp.utils;

public class LvMainLine {
    private String name;
    private String descriptor;
    private int icon;

    public LvMainLine(String nAme, String dEscriptor, int iCon) {
        name = nAme;
        descriptor = dEscriptor;
        icon = iCon;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescriptor() {
        return descriptor;
    }

    public void setDescriptor(String descriptor) {
        this.descriptor = descriptor;
    }

    public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }
}
