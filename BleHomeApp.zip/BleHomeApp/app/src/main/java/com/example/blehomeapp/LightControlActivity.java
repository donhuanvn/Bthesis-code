package com.example.blehomeapp;

import android.app.AlertDialog;
import android.app.Dialog;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Handler;
import android.os.IBinder;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.blehomeapp.services.BleForwardingService;
import com.example.blehomeapp.services.BluetoothLeService;
import com.example.blehomeapp.utils.HandlingMessage;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.StringTokenizer;
import java.util.UUID;

public class LightControlActivity extends AppCompatActivity {

    private static final String TAG = "LC_PANN";

    public static final String STRING_GATT_LIGHTING_CONTROL_SERVICE_UUID =
            "0000F00D-1212-EFDE-1523-785FEF13D123";
    public static final UUID GATT_LIGHTING_CONTROL_SERVICE_UUID =
            UUID.fromString(STRING_GATT_LIGHTING_CONTROL_SERVICE_UUID);
    public static final String STRING_WRITE_CHARACTERISTIC_OF_LC_SERVICE_UUID =
            "0000000B-1212-EFDE-1523-785FEF13D123";
    public static final UUID WRITE_CHARACTERISTIC_OF_LC_SERVICE_UUID =
            UUID.fromString(STRING_WRITE_CHARACTERISTIC_OF_LC_SERVICE_UUID);
    public static final String STRING_NOTIFY_CHARACTERISTIC_OF_LC_SERVICE_UUID =
            "000000A-1212-EFDE-1523-785FEF13D123";
    public static final UUID NOTIFY_CHARACTERISTIC_OF_LC_SERVICE_UUID =
            UUID.fromString(STRING_NOTIFY_CHARACTERISTIC_OF_LC_SERVICE_UUID);

    private static final int disableTextColor = 0xffaaaaaa; // darker_gray.
    private static final int enableLightStateTextColor = 0xffe80000;
    private static final int enableLuxValueTextColor = 0xffff8800; // holo_orange_dark.

    private RadioGroup rgSelectDestination;
    private RadioButton rbBleDirect, rbBleForwarding;
    private TextView txtControlTo, txtResult, txtLightState, txtLuxValue, txtNote;
    private Button btnGet, btnTurnOn, btnTurnOff, btnGetMode, btnSetAuto, btnSetManual, btnGetAuto;
    private ProgressBar pbTimeLive;
    private ButtonClickListener buttonClickListener;
    private Handler mHandler;

    private boolean mTimerProgressBarRunning;

    private BluetoothLeService mBluetoothLeService;
    private BleForwardingService mBleForwardingSerive;
    private boolean mBindedBluetoothLeService;
    private boolean mBindedBleForwardingSerive;
    private boolean mRegisteredBleSrvBroadcastReceiver;
    private boolean mHandledAfterResumeActivity;

    private boolean mNoDestination, mNoBleDirectDestination, mNoBleForwardingDestination;
    private boolean mLightControlAutoMode;
    private int mSelectedDestination;
    private int mActionOfGetButton;

    private static final int BLE_DIRECT = 0x0000;
    private static final int BLE_FORWARD = 0x0001;
    private static final int TIME_LIVE_OF_VALUES = 10000;

    private static final int NON_BUTTON_GET = 0x0000;
    private static final int BUTTON_GET = 0x0001;
    private static final int BUTTON_GET_MODE = 0x0002;
    private static final int BUTTON_GET_AUTO = 0x0003;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_light_control_panel);
        ThisActivityInitial();
        handleViewEvents();
    }

    @Override
    protected void onResume() {
        super.onResume();
        mBindedBluetoothLeService = false;
        mBindedBleForwardingSerive = false;
        mRegisteredBleSrvBroadcastReceiver = false;
        mHandledAfterResumeActivity = false;

        Intent intentBle = new Intent(LightControlActivity.this, BluetoothLeService.class);
        bindService(intentBle, mBleServiceConnection, BIND_AUTO_CREATE);

        Intent intentBleForw = new Intent(LightControlActivity.this, BleForwardingService.class);
        bindService(intentBleForw, mBleForwServiceConnection, BIND_AUTO_CREATE);
    }

    @Override
    protected void onPause() {
        super.onPause();
        HandleAfterPauseActivity();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_lc_pan, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            overridePendingTransition(R.anim.anim_intent_enter,R.anim.anim_intent_exit);
        }

        switch (item.getItemId()) {
            case R.id.lc_pan_menu_item_info:
                AlertDialog.Builder builder = new AlertDialog.Builder(LightControlActivity.this);
                builder.setTitle(R.string.lc_pan_menu_item_info);
                builder.setMessage(R.string.lc_pan_alertdialog_msg);
                builder.setCancelable(false);
                builder.setPositiveButton(R.string.lc_pan_alertdialog_button,
                        new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                builder.setNegativeButton("", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    //----------------------------------------------------------------------------------------------
    //-----------------------------Relative Bases of this Activity----------------------------------
    private void ThisActivityInitial() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

        getSupportActionBar().setTitle(R.string.lc_panel_title);

        mHandler = new Handler();

        //Binding Views.
        rgSelectDestination = (RadioGroup) findViewById(R.id.lc_pan_radioGroup);
        rbBleDirect = (RadioButton) findViewById(R.id.lc_pan_rb_ble_direct);
        rbBleForwarding = (RadioButton) findViewById(R.id.lc_pan_rb_ble_forw);
        txtControlTo = (TextView) findViewById(R.id.lc_pan_txt_control_to);
        txtLightState = (TextView) findViewById(R.id.lc_pan_txt_light_state);
        txtLuxValue = (TextView) findViewById(R.id.lc_pan_txt_lux);
        txtResult = (TextView) findViewById(R.id.lc_pan_txt_result);
        txtNote = (TextView) findViewById(R.id.lc_pan_txt_note);
        btnGet = (Button) findViewById(R.id.lc_pan_but_get_info);
        btnTurnOn = (Button) findViewById(R.id.lc_pan_but_turn_on);
        btnTurnOff = (Button) findViewById(R.id.lc_pan_but_turn_off);
        btnGetMode = (Button) findViewById(R.id.lc_pan_but_get_mode);
        btnSetAuto = (Button) findViewById(R.id.lc_pan_but_set_auto_mode);
        btnSetManual = (Button) findViewById(R.id.lc_pan_but_set_manual_mode);
        btnGetAuto = (Button) findViewById(R.id.lc_pan_but_get_auto);
        pbTimeLive = (ProgressBar) findViewById(R.id.lc_pan_progress_bar_time_live);

        buttonClickListener = new ButtonClickListener();
        btnGet.setOnClickListener(buttonClickListener);
        btnTurnOn.setOnClickListener(buttonClickListener);
        btnTurnOff.setOnClickListener(buttonClickListener);
        btnGetMode.setOnClickListener(buttonClickListener);
        btnSetAuto.setOnClickListener(buttonClickListener);
        btnSetManual.setOnClickListener(buttonClickListener);
        btnGetAuto.setOnClickListener(buttonClickListener);
    }

    private void HandleAfterResumeActivity() {
        //Check connection state.
        mNoDestination =
                mBluetoothLeService.getConnectionState() == BluetoothLeService.STATE_DISCONNECTED;

        if (mNoDestination) {
            Toast.makeText(mBluetoothLeService,
                    R.string.lc_panel_toast_no_connection, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        //check BLE Lighting Control Service.
        BluetoothGatt bluetoothGatt = null;
        BluetoothGattService bluetoothGattService = null;
        BluetoothGattCharacteristic writeCharacteristic = null, notifyCharacteristic = null;
        bluetoothGatt = mBluetoothLeService.getBluetoothGatt();
        if (bluetoothGatt != null)
            bluetoothGattService = bluetoothGatt.getService(GATT_LIGHTING_CONTROL_SERVICE_UUID);
        if (bluetoothGattService != null) {
            writeCharacteristic =
                    bluetoothGattService.getCharacteristic(WRITE_CHARACTERISTIC_OF_LC_SERVICE_UUID);
            notifyCharacteristic =
                    bluetoothGattService.getCharacteristic(NOTIFY_CHARACTERISTIC_OF_LC_SERVICE_UUID);
        }

        mNoBleDirectDestination =
                (writeCharacteristic == null) || (notifyCharacteristic == null);

        //Enable Notification on Local and Remote Device.
        if (!mNoBleDirectDestination)
            mNoBleDirectDestination =
                !mBluetoothLeService.setCharacteristicNotification(notifyCharacteristic,
                                                NOTIFY_CHARACTERISTIC_OF_LC_SERVICE_UUID,
                                                BluetoothLeService.DEFAULT_CCCD_UUID,
                                                true);

        if (mNoBleDirectDestination) rbBleDirect.setEnabled(false);
            else rbBleDirect.setEnabled(true);

        //không cần check BLE Forwarding Service vì phần này đã kiểm tra ở BleForwardingService.
        mNoBleForwardingDestination =
                mBleForwardingSerive.getSelectedDeviceAddress() == null;

        if (mNoBleForwardingDestination) rbBleForwarding.setEnabled(false);
            else rbBleForwarding.setEnabled(true);

        //kiểm tra lại mNoDestination.
        mNoDestination = mNoBleDirectDestination && mNoBleForwardingDestination;
        if (mNoDestination) {
            Toast.makeText(mBluetoothLeService,
                    R.string.lc_panel_toast_no_destination, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        switch (rgSelectDestination.getCheckedRadioButtonId()) {
            case R.id.lc_pan_rb_ble_direct:
                mSelectedDestination = BLE_DIRECT;
                txtControlTo.setText(mBluetoothLeService.getBluetoothDeviceName());
                break;
            case R.id.lc_pan_rb_ble_forw:
                mSelectedDestination = BLE_FORWARD;
                txtControlTo.setText(mBleForwardingSerive.getSelectedDeviceName());
                break;
        }

        if (!mRegisteredBleSrvBroadcastReceiver) {
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction(BluetoothLeService.ACTION_GATT_CONNECTIVITY_CHANGED);
            intentFilter.addAction(BluetoothLeService.ACTION_DATA_AVAILABLE);
            registerReceiver(mBleSrvBroadcastReceiver, intentFilter);
            mRegisteredBleSrvBroadcastReceiver = true;
        }
    }

    private void HandleAfterPauseActivity() {
        if (mRegisteredBleSrvBroadcastReceiver) {
            unregisterReceiver(mBleSrvBroadcastReceiver);
            mRegisteredBleSrvBroadcastReceiver = false;
        }

        if (mBindedBluetoothLeService) {
            unbindService(mBleForwServiceConnection);
            mBindedBluetoothLeService = false;
        }

        if (mBindedBleForwardingSerive) {
            unbindService(mBleServiceConnection);
            mBindedBleForwardingSerive = false;
        }
    }

    private void progressBarStart() {
        pbTimeLive.setProgress(pbTimeLive.getMax());

        if (!mTimerProgressBarRunning) {
            mTimerProgressBarRunning = true;
            mUpdateProgressBar.run();
        }
    }

    Runnable mUpdateProgressBar = new Runnable() {
        @Override
        public void run() {
            int currentVal = pbTimeLive.getProgress();
            if (currentVal == 0) {
                mHandler.removeCallbacksAndMessages(mUpdateProgressBar);
                mTimerProgressBarRunning = false;
                updateLightStateAndLuxValue(null, null);
            }

            int step = pbTimeLive.getMax()/500;
            pbTimeLive.setProgress(currentVal - step);

            if (currentVal > 0) {
                mHandler.postDelayed(mUpdateProgressBar, TIME_LIVE_OF_VALUES / 500);
            }
        }
    };

    //----------------------------------------------------------------------------------------------
    //----------------------------Functions interacting with Views----------------------------------
    private void updateTxtNodeWithTimeStamp() {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        final String timeStampString = simpleDateFormat.format(new Date());
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                txtNote.setText(timeStampString);
            }
        });
    }

    private void updateLightStateAndLuxValue(String lightState, String luxValue) {
        if (lightState != null && lightState.length()>0) {
            txtLightState.setText(lightState);
            txtLightState.setTextColor(enableLightStateTextColor);
        } else {
            txtLightState.setText(R.string.not_avail);
            txtLightState.setTextColor(disableTextColor);
        }
        String string = new String();
        if (luxValue != null && luxValue.length()>0) {
            string = luxValue + " " + getString(R.string.lc_panel_light_uint);
            txtLuxValue.setText(string);
            txtLuxValue.setTextColor(enableLuxValueTextColor);
        } else {
            string = getString(R.string.not_avail) + " " +getString(R.string.lc_panel_light_uint);
            txtLuxValue.setText(string);
            txtLuxValue.setTextColor(disableTextColor);
        }
    }

    //----------------------------------------------------------------------------------------------
    //------------------------------Handle View Events----------------------------------------------
    private void handleViewEvents() {
        rgSelectDestination.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                boolean turnToPreviousState = false;

                // có một repuest (get buttons) ở destination này chưa nhận được response thì chưa
                // chuyển được.
                if (mActionOfGetButton != NON_BUTTON_GET) {
                    turnToPreviousState = true;
                    Toast.makeText(LightControlActivity.this,
                            R.string.lc_panel_toast_has_not_received_respone,
                            Toast.LENGTH_SHORT).show();
                }

                switch (checkedId) {
                    case R.id.lc_pan_rb_ble_direct:
                        if (turnToPreviousState) {
                            rbBleDirect.setChecked(false);
                            rbBleForwarding.setChecked(true);
                            return;
                        }
                        mLightControlAutoMode = false;              //false in default.
                        mSelectedDestination = BLE_DIRECT;
                        txtControlTo.setText(mBluetoothLeService.getBluetoothDeviceName());
                        break;
                    case R.id.lc_pan_rb_ble_forw:
                        if (turnToPreviousState) {
                            rbBleDirect.setChecked(true);
                            rbBleForwarding.setChecked(false);
                            return;
                        }
                        mLightControlAutoMode = false;              //false in default.
                        mSelectedDestination = BLE_FORWARD;
                        txtControlTo.setText(mBleForwardingSerive.getSelectedDeviceName());
                        break;
                }
            }
        });
    }

    private class ButtonClickListener implements View.OnClickListener {

        @Override
        public void onClick(View v) {
            String msg = new String();

            switch (v.getId()) {
                case R.id.lc_pan_but_get_info:
                    Log.d(TAG, "Get info button was pressed.");
                    if (mActionOfGetButton == NON_BUTTON_GET) {
                        mActionOfGetButton = BUTTON_GET;
                    }
                    msg = getString(R.string.lc_panel_msg_get);
                    break;
                case R.id.lc_pan_but_turn_on:
                    Log.d(TAG, "Turn on button was pressed.");
                    progressBarStart();
                    updateLightStateAndLuxValue(getString(R.string.lc_panel_on), null);
                    updateTxtNodeWithTimeStamp();
                    msg = getString(R.string.lc_panel_msg_turn_on);
                    break;
                case R.id.lc_pan_but_turn_off:
                    Log.d(TAG, "Turn off button was pressed.");
                    progressBarStart();
                    updateLightStateAndLuxValue(getString(R.string.lc_panel_off), null);
                    updateTxtNodeWithTimeStamp();
                    msg = getString(R.string.lc_panel_msg_turn_off);
                    break;
                case R.id.lc_pan_but_get_mode:
                    Log.d(TAG, "Get mode button was pressed.");
                    if (mActionOfGetButton == NON_BUTTON_GET) {
                        mActionOfGetButton = BUTTON_GET_MODE;
                    }
                    msg = getString(R.string.lc_panel_msg_get_mode);
                    break;
                case R.id.lc_pan_but_set_auto_mode:
                    Log.d(TAG, "Set auto mode button was pressed.");
                    handleButtonSetAutoMode();
                    msg = null;
                    break;
                case R.id.lc_pan_but_set_manual_mode:
                    Log.d(TAG, "Set manual mode button was pressed.");
                    msg = getString(R.string.lc_panel_msg_set_manual);
                    break;
                case R.id.lc_pan_but_get_auto:
                    Log.d(TAG, "Get params of auto mode button was pressed.");
                    if (mActionOfGetButton == NON_BUTTON_GET) {
                        mActionOfGetButton = BUTTON_GET_AUTO;
                    }
                    msg = getString(R.string.lc_panel_msg_get_auto);
                    break;
            }

            if (msg != null && msg.length()>0)
                if (sendMessageToSelectedDestination(msg.getBytes())) {
                    Log.d(TAG, getString(R.string.lc_panel_log_send_success));
                } else {
                    Log.d(TAG, getString(R.string.lc_panel_log_send_failed));
                }
        }
    }

    private void handleButtonSetAutoMode() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_enter_auto_params);
        dialog.setCanceledOnTouchOutside(false);

        final EditText edtThreshold, edtInterval;
        Button btnOK = (Button) dialog.findViewById(R.id.lc_panel_dialog_but_ok);
        Button btnCannel = (Button) dialog.findViewById(R.id.lc_panel_dialog_but_cannel);
        edtThreshold = (EditText) dialog.findViewById(R.id.lc_pan_edt_threshold);
        edtInterval = (EditText) dialog.findViewById(R.id.lc_pan_edt_interval);

        btnOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //các chuỗi này chỉ chưa kí tự số 0-9.
                String thresholdString = edtThreshold.getText().toString();
                String intervalString = edtInterval.getText().toString();

                String messageToSend;
                if (thresholdString.equals("") || intervalString.equals("")) {
                    Toast.makeText(LightControlActivity.this,
                            R.string.lc_panel_toast_input_null, Toast.LENGTH_SHORT).show();
                    messageToSend = getString(R.string.lc_panel_msg_set_auto);
                } else {
                    messageToSend = getString(R.string.lc_panel_msg_set_auto_)
                            + intervalString + "_" + thresholdString; // set_mode_auto_<interval>_<threshold>;
                }
                if (sendMessageToSelectedDestination(messageToSend.getBytes())) {
                    mLightControlAutoMode = true;
                    Log.d(TAG, getString(R.string.lc_panel_log_send_success));
                } else {
                    Log.d(TAG, getString(R.string.lc_panel_log_send_failed));
                }

                dialog.dismiss();
            }
        });

        btnCannel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    //----------------------------------------------------------------------------------------------
    //--------------------------Send Message To Exactly Destination---------------------------------
    private boolean sendMessageToSelectedDestination(byte[] messageToSend) {
        switch (mSelectedDestination) {
            case BLE_DIRECT:
                return writeDataBleDirect(messageToSend);
            case BLE_FORWARD:
                String message = new String(messageToSend);
                String endNodeAddr = mBleForwardingSerive.getSelectedDeviceAddress();
                String messagetoEndNode = endNodeAddr + "_" + message;
                return writeDataBleForwarding(messagetoEndNode.getBytes());
        }

        return false;
    }

    private boolean writeDataBleDirect(byte[] messageToWrite) {
        return mBluetoothLeService.writeDataToRemoteBleDevice(
                GATT_LIGHTING_CONTROL_SERVICE_UUID,
                WRITE_CHARACTERISTIC_OF_LC_SERVICE_UUID,
                messageToWrite);
    }

    private boolean writeDataBleForwarding(byte[] messageToWrite) {
        return mBluetoothLeService.writeDataToRemoteBleDevice(
                BleForwardingService.GATT_FORWARDER_SERVICE_UUID,
                BleForwardingService.WRITE_CHARACTERISTIC_OF_FORWARDER_SERVICE_UUID,
                messageToWrite);
    }
    //----------------------------------------------------------------------------------------------
    //--------------------------------Handle Data Income--------------------------------------------
    private void handleResponseOfGetInfo(String response) {
        StringTokenizer stResponse = new StringTokenizer(response, "_");
        String luxString = new String();
        String stateString = new String();

        if (stResponse.hasMoreTokens()){
            luxString = stResponse.nextToken();
        }

        if (stResponse.hasMoreTokens()) {
            stateString = stResponse.nextToken().toUpperCase();
        }

        for (int i=0; i<luxString.length(); i++) {
            if (!Character.isDigit(luxString.charAt(i))) return;
        }
        if (!stateString.equals("ON") && !stateString.equals("OFF")) return;

        final String finalStateString = stateString;
        final String finalLuxString = luxString;

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                updateLightStateAndLuxValue(finalStateString, finalLuxString);
            }
        });
        updateTxtNodeWithTimeStamp();
        progressBarStart();
    }

    private void handleResponseOfGetMode(final String response) {

        if (response.toLowerCase().equals("manual")) {
            mLightControlAutoMode = false;
        } else if (response.toLowerCase().equals("auto")){
            mLightControlAutoMode = true;
        }

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (mLightControlAutoMode) {
                    txtResult.setText("Light is in automatic mode.");
                } else {
                    txtResult.setText("Light is in manual mode.");
                }
            }
        });

        updateTxtNodeWithTimeStamp();
    }

    private void handleResponseOfGetAuto(String response) {
        StringTokenizer stResponse = new StringTokenizer(response, "_");
        String thresholdString = new String();
        String intervalString = new String();

        if (stResponse.hasMoreTokens()){
            intervalString = stResponse.nextToken();
        }

        if (stResponse.hasMoreTokens()) {
            thresholdString = stResponse.nextToken();
        }

        final String result;
        if (intervalString.equals(getString(R.string.lc_panel_rep_default))) {
            result = getString(R.string.lc_panel_result_auto_default);
        } else {
            int i;
            for (i = 0; i<intervalString.length(); i++) {
                if (!Character.isDigit(intervalString.charAt(i))) return;
            }
            for (i = 0; i<thresholdString.length(); i++) {
                if (!Character.isDigit(thresholdString.charAt(i))) return;
            }

            result = "Interval is " + intervalString + " ms. Threshold is "
                    + thresholdString + " lux.";
        }

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                txtResult.setText(result);
            }
        });
        updateTxtNodeWithTimeStamp();
    }

    private void handleDataIncome(String message) {

        // một response sẽ đi với 1 request trước đớ (nhấn nút).
        // ngoại lệ trường hợp auto mode, các gói tin gửi về theo chu kỳ.
        if (mActionOfGetButton == NON_BUTTON_GET && !mLightControlAutoMode) return;

        Log.d(TAG, getString(R.string.lc_panel_log_receive_msg) + " " + message);

        if (mLightControlAutoMode) handleResponseOfGetInfo(message);

        switch (mActionOfGetButton) {
            case BUTTON_GET:
                mActionOfGetButton = NON_BUTTON_GET;
                handleResponseOfGetInfo(message);
                break;
            case BUTTON_GET_MODE:
                mActionOfGetButton = NON_BUTTON_GET;
                handleResponseOfGetMode(message);
                break;
            case BUTTON_GET_AUTO:
                mActionOfGetButton = NON_BUTTON_GET;
                handleResponseOfGetAuto(message);
                break;
        }
    }

    //----------------------------------------------------------------------------------------------
    //-----------------------------------Broadcast Receivers----------------------------------------
    private BroadcastReceiver mBleSrvBroadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            switch (intent.getAction()) {
                case BluetoothLeService.ACTION_DATA_AVAILABLE:
                    BluetoothGattCharacteristic characteristic =
                            mBluetoothLeService.getChangedCharacteristic();

                    if (characteristic.getUuid().equals(NOTIFY_CHARACTERISTIC_OF_LC_SERVICE_UUID)) {

                            handleDataIncome(new String(characteristic.getValue()));

                    } else if (characteristic.getUuid().equals(
                            BleForwardingService.NOTIFY_CHARACTERISTIC_OF_FORWARDER_SERVICE_UUID)) {

                            handleDataIncome(new String(characteristic.getValue()));
                    }
                    break;
                case BluetoothLeService.ACTION_GATT_CONNECTIVITY_CHANGED:
                    if (mBluetoothLeService.getConnectionState() == BluetoothLeService.STATE_DISCONNECTED) {
                        Toast.makeText(context,
                                R.string.lc_panel_toast_lost_connection, Toast.LENGTH_SHORT).show();
                        finish();
                    }
                    break;
            }
        }
    };

    //----------------------------------------------------------------------------------------------
    //---------------------------SERVICE CONNECTIONS------------------------------------------------
    private ServiceConnection mBleServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            mBluetoothLeService =
                    (BluetoothLeService) ((BluetoothLeService.LocalBinder)service).getService();

            if (!mBluetoothLeService.initialize()) {
                Log.e(TAG, "Unable to initialize Bluetooth");
                finish();
            }
            mBindedBluetoothLeService = true;

            if (mBindedBluetoothLeService && mBindedBleForwardingSerive && !mHandledAfterResumeActivity) {
                mHandledAfterResumeActivity = true;
                HandleAfterResumeActivity();
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mBindedBluetoothLeService = false;
            mBluetoothLeService = null;
        }
    };

    private ServiceConnection mBleForwServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            mBleForwardingSerive =
                    (BleForwardingService) ((BleForwardingService.LocalBinder)service).getService();
            mBindedBleForwardingSerive = true;

            if (mBindedBluetoothLeService && mBindedBleForwardingSerive && !mHandledAfterResumeActivity) {
                mHandledAfterResumeActivity = true;
                HandleAfterResumeActivity();
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mBindedBleForwardingSerive = false;
            mBleForwardingSerive = null;
        }
    };
}
