package com.example.blehomeapp.utils;

import android.content.Context;
import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.blehomeapp.R;

import java.util.List;

public class LvMainAdapter extends BaseAdapter {

    private Context context;
    private int layout;
    private List<LvMainLine> lineList;

    public LvMainAdapter(Context context, int layout, List<LvMainLine> lineList) {
        this.context = context;
        this.layout = layout;
        this.lineList = lineList;
    }

    @Override
    public int getCount() {
        return lineList.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater =
                (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        convertView = inflater.inflate(layout, null);

        //ánh xạ View
        TextView txtName = (TextView) convertView.findViewById(R.id.text_view_lv_main_name);
        TextView txtDescriptor =
                (TextView) convertView.findViewById(R.id.text_view_lv_main_descriptor);
        ImageView imgIcon = (ImageView) convertView.findViewById(R.id.image_view_lv_main_icon);

        //gán giá trị
        txtName.setText(lineList.get(position).getName());
        txtDescriptor.setText(lineList.get(position).getDescriptor());
        imgIcon.setImageResource(lineList.get(position).getIcon());

        return convertView;
    }
}
