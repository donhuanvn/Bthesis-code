package com.example.blehomeapp.services;

import android.app.Service;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.Binder;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.util.Log;

import java.util.UUID;

public class BleForwardingService extends Service {

    private final static String TAG = "BLE_FORW_SRV";

    private IBinder iBinder = new LocalBinder();
    private BluetoothLeService mBluetoothLeService;

    public final static String STRING_GATT_FORWARDER_SERVICE_UUID = "0000FEED-1212-EFDE-1523-785FEF13D123";
    public final static UUID GATT_FORWARDER_SERVICE_UUID = UUID.fromString(STRING_GATT_FORWARDER_SERVICE_UUID);
    public final static String STRING_WRITE_CHARACTERISTIC_OF_FORWARDER_SERVICE_UUID =
            "0000000D-1212-EFDE-1523-785FEF13D123";
    public final static UUID WRITE_CHARACTERISTIC_OF_FORWARDER_SERVICE_UUID =
            UUID.fromString(STRING_WRITE_CHARACTERISTIC_OF_FORWARDER_SERVICE_UUID);
    public final static String STRING_NOTIFY_CHARACTERISTIC_OF_FORWARDER_SERVICE_UUID =
            "0000000C-1212-EFDE-1523-785FEF13D123";
    public final static UUID NOTIFY_CHARACTERISTIC_OF_FORWARDER_SERVICE_UUID =
            UUID.fromString(STRING_NOTIFY_CHARACTERISTIC_OF_FORWARDER_SERVICE_UUID);

    private int currentConnectionState;
    private String currentDeviceAddress;
    private boolean mHasGattBleForwarderService;
    private boolean mSetNotification;
    private boolean mHasReadyBleForwarder;
    private String forwaderDeviceAddress;
    private String selectedDeviceName;
    private String selectedDeviceAddress;

    public final static String ACTION_BLE_FORWARDER_UPDATE =
            "com.nhuan.thesis.ACTION_BLE_FORWARDER_UPDATE";


    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        Intent intentBleSrv = new Intent(BleForwardingService.this, BluetoothLeService.class);
        bindService(intentBleSrv, mBleSrvConnection, BIND_AUTO_CREATE);
        return iBinder;
    }

    public class LocalBinder extends Binder {
        public BleForwardingService getService() {
            return BleForwardingService.this;
        }
    }

    @Override
    public boolean onUnbind(Intent intent) {
        unbindService(mBleSrvConnection);
        unregisterReceiver(mBleSrvBroadcastReceiver);
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    public boolean writeDataToRemoteBleDevice(byte[] messageToWrite) {
        return mBluetoothLeService.writeDataToRemoteBleDevice(GATT_FORWARDER_SERVICE_UUID,
                WRITE_CHARACTERISTIC_OF_FORWARDER_SERVICE_UUID, messageToWrite);
    }

    //----------------------------------------------------------------------------------------------
    //----------------------------GETTER AND SETTER-------------------------------------------------

    public String getForwaderDeviceAddress() {
        return forwaderDeviceAddress;
    }

    public String getSelectedDeviceName() {
        return selectedDeviceName;
    }

    public String getSelectedDeviceAddress() {
        return selectedDeviceAddress;
    }

    public int getCurrentConnectionState() {
        return currentConnectionState;
    }

    public String getCurrentDeviceAddress() {
        return currentDeviceAddress;
    }

    public boolean isHasGattBleForwarderService() {
        return mHasGattBleForwarderService;
    }

    public boolean isSetNotification() {
        return mSetNotification;
    }

    public boolean isHasReadyBleForwarder() {
        return mHasReadyBleForwarder;
    }


    public void setForwaderDeviceAddress(String forwaderDeviceAddress) {
        if (mHasReadyBleForwarder) {
            this.forwaderDeviceAddress = forwaderDeviceAddress;
        } else {
            Log.e(TAG, "Setting in not connected state!");
        }
    }

    public void setSelectedDeviceName(String selectedDeviceName) {
        if (mHasReadyBleForwarder) {
            this.selectedDeviceName = selectedDeviceName;
        } else {
            Log.e(TAG, "Setting in not connected state!");
        }
    }

    public void setSelectedDeviceAddress(String selectedDeviceAddress) {
        if (currentConnectionState == BluetoothLeService.STATE_CONNECTED) {
            this.selectedDeviceAddress = selectedDeviceAddress;
        } else {
            Log.e(TAG, "Setting in not connected state!");
        }
    }
    //----------------------------------------------------------------------------------------------
    //------------------------BROASTCAST RECEIVER FROM BluetoothLeService---------------------------
    private BroadcastReceiver mBleSrvBroadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(BluetoothLeService.ACTION_GATT_CONNECTIVITY_CHANGED)) {
                if (mBluetoothLeService.getConnectionState() == BluetoothLeService.STATE_DISCONNECTED) {
                    onDisconnectedBroadcast();
                } else if (mBluetoothLeService.getConnectionState() == BluetoothLeService.STATE_CONNECTED) {
                    onConnectedBroadcast();
                }
            } else if (intent.getAction().equals(BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED)){
                onGattServiceDiscovered();
            };
        }
    };

    private void onDisconnectedBroadcast() {
        currentConnectionState = BluetoothLeService.STATE_DISCONNECTED;
        currentDeviceAddress = null;
        forwaderDeviceAddress = null;
        selectedDeviceAddress = null;
        selectedDeviceName = null;
        mHasGattBleForwarderService = false;
        mSetNotification = false;
        mHasReadyBleForwarder = false;

        Intent intent = new Intent();
        intent.setAction(ACTION_BLE_FORWARDER_UPDATE);
        sendBroadcast(intent);
    }

    private void onConnectedBroadcast() {
        currentConnectionState = BluetoothLeService.STATE_CONNECTED;
        currentDeviceAddress = mBluetoothLeService.getBluetoothDeviceAddress();

        Intent intent = new Intent();
        intent.setAction(ACTION_BLE_FORWARDER_UPDATE);
        sendBroadcast(intent);
    }

    private void onGattServiceDiscovered() {
        BluetoothGatt mBleGatt = mBluetoothLeService.getBluetoothGatt();
        BluetoothGattService mBleGattForwarderService = null;
        BluetoothGattCharacteristic notifyCharacteristic = null;
        BluetoothGattCharacteristic writeCharacteristic = null;
        if (mBleGatt != null)
            mBleGattForwarderService =  mBleGatt.getService(GATT_FORWARDER_SERVICE_UUID);
        if (mBleGattForwarderService != null) {
            notifyCharacteristic =
                    mBleGattForwarderService.getCharacteristic(NOTIFY_CHARACTERISTIC_OF_FORWARDER_SERVICE_UUID);
            writeCharacteristic =
                    mBleGattForwarderService.getCharacteristic(WRITE_CHARACTERISTIC_OF_FORWARDER_SERVICE_UUID);
        }

        if (notifyCharacteristic == null ||
            writeCharacteristic == null) {
            mHasGattBleForwarderService = false;
            return;
        }

        mHasGattBleForwarderService = true;
        mSetNotification = mBluetoothLeService.setCharacteristicNotification(
                notifyCharacteristic,
                NOTIFY_CHARACTERISTIC_OF_FORWARDER_SERVICE_UUID,
                BluetoothLeService.DEFAULT_CCCD_UUID,
                true); //Chưa check response của gói tin enable notification.

        mHasReadyBleForwarder = mSetNotification && mHasGattBleForwarderService;

        Intent intent = new Intent();
        intent.setAction(ACTION_BLE_FORWARDER_UPDATE);
        sendBroadcast(intent);
    }

    //----------------------------------------------------------------------------------------------
    //------------------------SERVICE CONNECTION to BluetoothLeService------------------------------
    private ServiceConnection mBleSrvConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            mBluetoothLeService =
                    (BluetoothLeService) ((BluetoothLeService.LocalBinder)service).getService();

            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction(BluetoothLeService.ACTION_GATT_CONNECTIVITY_CHANGED);
            intentFilter.addAction(BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED);
            registerReceiver(mBleSrvBroadcastReceiver, intentFilter);
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mBluetoothLeService = null;
        }
    };
}
