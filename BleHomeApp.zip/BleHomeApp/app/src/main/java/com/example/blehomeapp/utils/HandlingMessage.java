package com.example.blehomeapp.utils;

import android.content.Context;
import android.util.Log;

import com.example.blehomeapp.services.BleForwardingService;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class HandlingMessage {

    private static final String TAG = "HANDLING_MESSAGE";

    private static String byteToHex(byte num) {
        char[] hexDigits = new char[2];

        hexDigits[0] = Character.forDigit((num>>4) & 0x0F, 16);
        hexDigits[1] = Character.forDigit(num & 0x0F, 16);

        return new String(hexDigits);
    }

    public static String getIpv6FromBleForwarderMessage(byte[] messageToHandle) {
        StringBuilder stringBuilder = new StringBuilder();

        for (int i = 0; i<16; i++) {
            if ((i % 2) == 0) {
                if (i != 0) stringBuilder.append(":");

//                if (messageToHandle[i] == 0 || messageToHandle[i+1] == 0) {
//                    stringBuilder.append("0");
//                    i++;
//                    continue;
//                }
            }
            stringBuilder.append(byteToHex(messageToHandle[i]));
        }

        return stringBuilder.toString().toUpperCase();
    }

    public static String getNodeNameFromBleForwarderMessage(byte[] messageToHandle) {
        if (messageToHandle.length <= 17) return null; //message format: <ipv6-128bits>"_"<name>
        byte[] nameByte = new byte[20];

        for (int i = 17; i<messageToHandle.length; i++) {
            if (messageToHandle[i] == 0) break;
            nameByte[i-17] = messageToHandle[i];
        }

        return new String(nameByte).trim();
    }

    public static ArrayList<Byte> bytesToArrayList(byte[] arr) {
        ArrayList<Byte> arrayList = new ArrayList<>();

        for (int i=0; i<arr.length; i++) {
            arrayList.add(arr[i]);
        }

        return arrayList;
    }

    public static byte[] arrayListToBytes(ArrayList<Byte> arrayList) {
        byte[] result = new byte[arrayList.size()];

        for (int i=0; i<arrayList.size(); i++) {
            result[i] = arrayList.get(i);
        }

        return result;
    }

    private static byte[] concatTwoByteArray(final byte[] bytes1, final byte[] bytes2) {
        byte[] result = new byte[bytes1.length + bytes2.length];
        for (int i = 0; i<bytes1.length + bytes2.length; i++) {
            if (i<bytes1.length) result[i] = bytes1[i];
            else result[i] = bytes2[i-bytes1.length];
        }

        return result;
    }

    private static byte[] getRawIpv6String(final String ipv6String) {
        StringBuilder sbIpv6;
        StringTokenizer st;
        byte[] rawIpv6 = new byte[16];

        sbIpv6 = new StringBuilder();
        st = new StringTokenizer(ipv6String, ":"); // ABCD:0:ABCD:1:2:3:4:5

        while (st.hasMoreTokens()) {
            String octet = st.nextToken();
            while (octet.length()<4) octet = "0" + octet;
            sbIpv6.append(octet);
        }

        //sbIpv6: ABCD0000ABCD00010002000300040005

        if (sbIpv6.length()>32) {
            Log.d(TAG, "IPv6 Address is over maximum length!");
            return null;
        }

        for (int i=0; i<sbIpv6.length(); i+=2) {
            int msb = Character.digit(sbIpv6.charAt(i),16);
            int lsb = Character.digit(sbIpv6.charAt(i), 16);
            rawIpv6[i/2] = (byte) (((msb<<4)&0x00F0) | (lsb & 0x000F));
        }

        return rawIpv6;
    }

    public static byte[] addEndNodeAddressIntoMessage(String endNodeIpv6Address, byte[] messageToHandle) {
        byte[] ipv6Raw = getRawIpv6String(endNodeIpv6Address);
        if (ipv6Raw == null) return null;
        final byte[] t = {'_'};
        byte[] result = concatTwoByteArray(ipv6Raw, t);
        result = concatTwoByteArray(result, messageToHandle);
        return result;
    }
}
