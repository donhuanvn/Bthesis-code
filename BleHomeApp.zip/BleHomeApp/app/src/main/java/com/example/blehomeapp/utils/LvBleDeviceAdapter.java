package com.example.blehomeapp.utils;

import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.blehomeapp.R;

import java.util.List;

public class LvBleDeviceAdapter extends BaseAdapter {

    private Context context;
    private int layout;
    private List<LvBleDeviceLine> bleDeviceList;

    public LvBleDeviceAdapter(Context context, int layout, List<LvBleDeviceLine> bleDeviceList) {
        this.context = context;
        this.layout = layout;
        this.bleDeviceList = bleDeviceList;
    }

    @Override
    public int getCount() {
        return bleDeviceList.size();
    }

    @Override
    public Object getItem(int position) {
        return bleDeviceList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder viewHolder;
        // General ListView optimization code.
        if (convertView == null) {
            LayoutInflater inflater =
                    (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(layout, null);

            viewHolder = new ViewHolder();
            viewHolder.txtName = (TextView) convertView.findViewById(R.id.lv_device_txt_name);
            viewHolder.txtAddr = (TextView) convertView.findViewById(R.id.lv_device_txt_address);

            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        viewHolder.txtName.setText(bleDeviceList.get(position).getDeviceName());
        viewHolder.txtAddr.setText(bleDeviceList.get(position).getDeviceAddr());

        return convertView;
    }

    static class ViewHolder {
        TextView txtName;
        TextView txtAddr;
    }
}
