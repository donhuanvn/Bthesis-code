package com.example.blehomeapp;

import android.bluetooth.BluetoothGattCharacteristic;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.IBinder;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.blehomeapp.services.BleForwardingService;
import com.example.blehomeapp.services.BluetoothLeService;
import com.example.blehomeapp.utils.HandlingMessage;
import com.example.blehomeapp.utils.LvBleDeviceAdapter;
import com.example.blehomeapp.utils.LvBleDeviceLine;

import java.util.ArrayList;

public class BleForwardingActivity extends AppCompatActivity {
    private final static String TAG = "BLE_FORW";

    private Button btnDiscover;
    private ListView lvDiscoveredNode;
    private ArrayList<LvBleDeviceLine> arrayDiscoveredNode;
    private LvBleDeviceAdapter lvDiscoveredNodeAdapter;
    private TextView txtStatus;
    private TextView txtNote;

    private BluetoothLeService mBluetoothLeService;
    private BleForwardingService mBleForwardingSerive;
    private boolean mBindedBluetoothLeService;
    private boolean mBindedBleForwardingSerive;
    private boolean mHandledAfterResumeActivity;

    private Handler mHandler;
    private boolean mDiscovering;

    private final static int MAX_DISCOVER_PERIOD = 4000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ble_forwarding);
        ThisActivityInitial();

        btnDiscover.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!mDiscovering) {
                    //không cần kiểm tra forwarder present vì, Discover Button đã được cấu hình enable,
                    //disable theo forwarder present tại broadcast receiver.
                    if (!mBleForwardingSerive.writeDataToRemoteBleDevice(
                            getString(R.string.msg_discover).getBytes())) return; //Send "discover" command.

                    mHandler = new Handler();
                    mHandler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            mDiscovering = false;

                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    btnDiscover.setText(getString(R.string.ble_forw_but_discover));
                                    updateStatus(getString(R.string.ble_forw_status_discover_completed));
                                }
                            });
                        }
                    }, MAX_DISCOVER_PERIOD);

                    mDiscovering = true;

                    mBleForwardingSerive.setForwaderDeviceAddress(null);
                    mBleForwardingSerive.setSelectedDeviceAddress(null);
                    mBleForwardingSerive.setSelectedDeviceName(null);

                    arrayDiscoveredNode.clear();

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            btnDiscover.setText(getString(R.string.ble_forw_but_stop_discover));
                            updateStatus(getString(R.string.ble_forw_status_discovering));
                            lvDiscoveredNodeAdapter.notifyDataSetChanged();
                        }
                    });
                } else {
                    mDiscovering = false;
                    mHandler.removeCallbacksAndMessages(null);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            btnDiscover.setText(getString(R.string.ble_forw_but_discover));
                            updateStatus(getString(R.string.ble_forw_status_discovering_stopped));
                        }
                    });
                }
            }
        });

        lvDiscoveredNode.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //không cần kiểm tra forwarder present vì trong list view sẽ bị clear khi forwarder
                //not present.
                if (mBleForwardingSerive.getForwaderDeviceAddress() != null &&
                    mBleForwardingSerive.getSelectedDeviceAddress() != null) {
                    Toast.makeText(mBluetoothLeService,
                            R.string.ble_forw_toast_device_selected, Toast.LENGTH_SHORT).show();
                    return;
                }

                if (mDiscovering) {
                    mHandler.removeCallbacksAndMessages(null);
                    mDiscovering = false;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            btnDiscover.setText(R.string.ble_forw_but_discover);
                        }
                    });
                }

                //set Selected End Node (Device) cho BleForwardingService.
                //các giá trị này sẽ bị clear nếu rớt kết nối, không được backup cho reconnect.
                mBleForwardingSerive.setForwaderDeviceAddress(
                        mBluetoothLeService.getBluetoothDeviceAddress());
                mBleForwardingSerive.setSelectedDeviceName(
                        arrayDiscoveredNode.get(position).getDeviceName());
                mBleForwardingSerive.setSelectedDeviceAddress(
                        arrayDiscoveredNode.get(position).getDeviceAddr());

                arrayDiscoveredNode.clear();
                arrayDiscoveredNode.add(new LvBleDeviceLine(BleForwardingActivity.this,
                                        mBleForwardingSerive.getSelectedDeviceName(),
                                        mBleForwardingSerive.getSelectedDeviceAddress()));

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        updateStatus(getString(R.string.ble_forw_status_selected_node));
                        lvDiscoveredNodeAdapter.notifyDataSetChanged();
                    }
                });
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        mBindedBleForwardingSerive = false;
        mBindedBluetoothLeService = false;
        mHandledAfterResumeActivity = false;

        Intent intentBle = new Intent(BleForwardingActivity.this, BluetoothLeService.class);
        bindService(intentBle, mBleServiceConnection, BIND_AUTO_CREATE);

        Intent intentBleForw = new Intent(BleForwardingActivity.this, BleForwardingService.class);
        bindService(intentBleForw, mBleForwServiceConnection, BIND_AUTO_CREATE);
    }

    @Override
    protected void onPause() {
        super.onPause();
        HandleAfterPauseActivity();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            overridePendingTransition(R.anim.anim_intent_enter,R.anim.anim_intent_exit);
        }
        return super.onOptionsItemSelected(item);
    }

    private void ThisActivityInitial() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

        getSupportActionBar().setTitle(R.string.ble_forw_title);

        txtNote = (TextView) findViewById(R.id.ble_forw_txt_note);
        txtStatus = (TextView) findViewById(R.id.ble_forw_txt_status);
        btnDiscover = (Button) findViewById(R.id.ble_forw_but_discover);
        lvDiscoveredNode = (ListView) findViewById(R.id.ble_forw_list_view_end_nodes);
        arrayDiscoveredNode = new ArrayList<LvBleDeviceLine>();
        lvDiscoveredNodeAdapter =
                new LvBleDeviceAdapter(this,
                        R.layout.list_view_ble_device_line, arrayDiscoveredNode);
        lvDiscoveredNode.setAdapter(lvDiscoveredNodeAdapter);

        mHandler = new Handler();
    }

    private void updateStatus(String stringStatus) {
        txtStatus.setText(stringStatus);
    }

    private void updateNote(String stringNote) {
        txtNote.setText(stringNote);
    }

    private void updateThisActivityUi() {
        final boolean isBleConnected =
                (mBleForwardingSerive.getCurrentConnectionState() == BluetoothLeService.STATE_CONNECTED);
        final boolean hasGattService = mBleForwardingSerive.isHasGattBleForwarderService();
        final boolean hasReadyDevice = mBleForwardingSerive.isHasReadyBleForwarder();

        final boolean btnEnable;
        final String stringTxtNote;
        final String stringTxtStatus;

        arrayDiscoveredNode.clear();

        do {
            if (!isBleConnected) {
                btnEnable = false;
                stringTxtNote = getString(R.string.ble_forw_note_no_ble_connection);
                stringTxtStatus = getString(R.string.welcome_short);
                break;
            }

            if (!hasGattService) {
                btnEnable = false;
                stringTxtNote = getString(R.string.ble_forw_note_has_connection_to)
                        +" "+ mBleForwardingSerive.getCurrentDeviceAddress();
                stringTxtStatus = getString(R.string.ble_forw_status_no_gatt_service);
                break;
            }

            if (!hasReadyDevice) {
                btnEnable = false;
                stringTxtNote = getString(R.string.ble_forw_note_has_connection_to)
                        +" "+ mBleForwardingSerive.getCurrentDeviceAddress();
                stringTxtStatus = getString(R.string.ble_forw_status_not_enable_notification);
                break;
            } else {
                btnEnable = true;
                stringTxtNote = getString(R.string.ble_forw_note_has_connection_to)
                        +" "+ mBleForwardingSerive.getCurrentDeviceAddress();
                stringTxtStatus = getString(R.string.ble_forw_status_ready);

                String selectedNodeName = mBleForwardingSerive.getSelectedDeviceName();
                String selectedNodeAddr = mBleForwardingSerive.getSelectedDeviceAddress();

                if (selectedNodeAddr != null) {
                    LvBleDeviceLine selectedNodeForLv =
                            new LvBleDeviceLine(BleForwardingActivity.this,
                                                selectedNodeName,
                                                selectedNodeAddr);
                    arrayDiscoveredNode.add(selectedNodeForLv);
                }
                break;
            }
        } while (false);

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                btnDiscover.setEnabled(btnEnable);
                updateNote(stringTxtNote);
                updateStatus(stringTxtStatus);
                lvDiscoveredNodeAdapter.notifyDataSetChanged();
            }
        });
    }

    private void HandleAfterResumeActivity() {
        //bind mBleForwServiceConnection và mBleServiceConnection được thực hiện trong hàm onResume.
        //Hàm này chạy sau khi 2 services trên đã bind thành công, để đảm bảo có 2 ibinder mà dùng.

        updateThisActivityUi();

        IntentFilter intentFilterBleForw = new IntentFilter();
        intentFilterBleForw.addAction(BleForwardingService.ACTION_BLE_FORWARDER_UPDATE);
        registerReceiver(mBleForwBroadcastReceiver, intentFilterBleForw);

        IntentFilter intentFilterBleDataAvail = new IntentFilter();
        intentFilterBleDataAvail.addAction(BluetoothLeService.ACTION_DATA_AVAILABLE);
        registerReceiver(mBleForwarderDataAvailBroadcastReceiver, intentFilterBleDataAvail);
    }

    private void HandleAfterPauseActivity() {
        unregisterReceiver(mBleForwBroadcastReceiver);
        unregisterReceiver(mBleForwarderDataAvailBroadcastReceiver);
        unbindService(mBleForwServiceConnection);
        mBindedBleForwardingSerive = false;
        unbindService(mBleServiceConnection);
        mBindedBluetoothLeService = false;
    }

    private void HandleIncomeBleForwarderMessage() {
        if (!mDiscovering) return;

        BluetoothGattCharacteristic characteristic
                = mBluetoothLeService.getChangedCharacteristic();

        byte[] messageToHandle = characteristic.getValue();
        int endingMessage = characteristic.getIntValue(BluetoothGattCharacteristic.FORMAT_UINT16, 0);
        if (endingMessage == arrayDiscoveredNode.size()) {
            Log.d(TAG, "received a message inform that discovering on the remote BLE device finished - "
                        + endingMessage);
            return;
        }

        if (messageToHandle.length<16) {
            Log.d(TAG, "received message is not in BLE Forwarder Message format!");
            return;
        }

        String nodeIpv6Addr = HandlingMessage.getIpv6FromBleForwarderMessage(messageToHandle);
        String nodeName = HandlingMessage.getNodeNameFromBleForwarderMessage(messageToHandle);

        if (nodeName == null || nodeName.length()<1) nodeName = getString(R.string.unknown_device);

        for (int i = 0; i<arrayDiscoveredNode.size(); i++) {
            if (arrayDiscoveredNode.get(i).getDeviceAddr().equals(nodeIpv6Addr)) return;
        }

        arrayDiscoveredNode.add(new LvBleDeviceLine(BleForwardingActivity.this,
                                                    nodeName, nodeIpv6Addr));
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                lvDiscoveredNodeAdapter.notifyDataSetChanged();
            }
        });
    }

    //----------------------------------------------------------------------------------------------
    //--------------------------------------Broadcast Receivers-------------------------------------
    private BroadcastReceiver mBleForwBroadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (!intent.getAction().equals(BleForwardingService.ACTION_BLE_FORWARDER_UPDATE)) return;
            updateThisActivityUi();
        }
    };

    private BroadcastReceiver mBleForwarderDataAvailBroadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (!intent.getAction().equals(BluetoothLeService.ACTION_DATA_AVAILABLE)) return;

            if (!mDiscovering) return;

            BluetoothGattCharacteristic characteristic
                    = mBluetoothLeService.getChangedCharacteristic();
            if (!characteristic.getUuid().equals(BleForwardingService.NOTIFY_CHARACTERISTIC_OF_FORWARDER_SERVICE_UUID))
                return;

            HandleIncomeBleForwarderMessage();
        }
    };

    //----------------------------------------------------------------------------------------------
    //---------------------------SERVICE CONNECTIONS------------------------------------------------
    private ServiceConnection mBleServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            mBluetoothLeService =
                    (BluetoothLeService) ((BluetoothLeService.LocalBinder)service).getService();

            if (!mBluetoothLeService.initialize()) {
                Log.e(TAG, "Unable to initialize Bluetooth");
                finish();
            }

            mBindedBluetoothLeService = true;

            if (mBindedBluetoothLeService && mBindedBleForwardingSerive && !mHandledAfterResumeActivity) {
                mHandledAfterResumeActivity = true;
                HandleAfterResumeActivity();
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mBindedBluetoothLeService = false;
            mBluetoothLeService = null;
        }
    };

    private ServiceConnection mBleForwServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            mBleForwardingSerive =
                    (BleForwardingService) ((BleForwardingService.LocalBinder)service).getService();

            mBindedBleForwardingSerive = true;

            if (mBindedBluetoothLeService && mBindedBleForwardingSerive && !mHandledAfterResumeActivity) {
                mHandledAfterResumeActivity = true;
                HandleAfterResumeActivity();
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mBindedBleForwardingSerive = false;
            mBleForwardingSerive = null;
        }
    };
}
