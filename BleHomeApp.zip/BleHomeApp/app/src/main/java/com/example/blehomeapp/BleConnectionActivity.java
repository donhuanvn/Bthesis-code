package com.example.blehomeapp;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.blehomeapp.services.BluetoothLeService;
import com.example.blehomeapp.utils.LvBleDeviceAdapter;
import com.example.blehomeapp.utils.LvBleDeviceLine;

import java.util.ArrayList;
import java.util.List;

public class BleConnectionActivity extends AppCompatActivity {

    private final static String TAG = "BLE_SCAN";

    private TextView txtStatus;
    private Button btnBleControl; //Scan, Stop Scan, Refresh
    private ListView lvScannedBleDevice;
    private ArrayList<LvBleDeviceLine> arrayScannedBleDevice;
    private LvBleDeviceAdapter lvBleDeviceAdapter;

    private BluetoothAdapter mBluetoothAdapter;
    private BluetoothLeScanner mBluetoothLeScanner;
    private ArrayList<BluetoothDevice> mScanResults;
    private ThisBleScanCallback mBleScanCallback;

    private boolean mScanning;
    private boolean mConnecting;
    private Handler mHandler;

    private BluetoothLeService mBluetoothLeService;

    private static final int REQUEST_ENABLE_BT = 0x0001;
    private static final int REQUEST_FINE_LOCATION = 0x0002;
    // Stops scanning after 10 seconds.
    private static final long SCAN_PERIOD = 10000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ble_connection);
        ThisActivityInitial();
        InitialBle();

        btnBleControl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!hasPermissionsforBle()) return;
                if (mBluetoothLeService.getConnectionState() == mBluetoothLeService.STATE_CONNECTED) {
                    mBluetoothLeService.disconnect();
                    return;
                }
                if (!mScanning) {
                    scanBleDevice(true);
                } else {
                    scanBleDevice(false);
                }
            }
        });

        lvScannedBleDevice.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                BluetoothDevice device = null;
                if (position < mScanResults.size()) {
                    device = mScanResults.get(position);
                    if (device == null) {
                        Toast.makeText(mBluetoothLeService, "Error happen! - null device.", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }

                if (mBluetoothLeService.getConnectionState() == BluetoothLeService.STATE_CONNECTED ||
                        mBluetoothLeService.getConnectionState() == BluetoothLeService.STATE_CONNECTING) {
                    Toast.makeText(mBluetoothLeService, "A ble connection has existed!", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (mScanning) {
                    mScanning = false;
                    scanBleDevice(false);
                }

                if (device != null && !mConnecting) {
                    mConnecting = mBluetoothLeService.connect(device.getAddress());
                    Log.d(TAG, "Attempting to connect to "+device.getName()+", "+device.getAddress());
                }
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            overridePendingTransition(R.anim.anim_intent_enter,R.anim.anim_intent_exit);
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onResume() {
        super.onResume();

        Intent intent = new Intent(this, BluetoothLeService.class);
        bindService(intent, mBleServiceConnection, BIND_AUTO_CREATE);
    }

    @Override
    protected void onPause() {
        super.onPause();

        //Stop scanning progress and unpeer to BluetoothLeService.
        scanBleDevice(false);
        unregisterReceiver(mBleSrvBoardcastReceiver);
        unbindService(mBleServiceConnection);
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        // User chose not to enable Bluetooth.
        if (requestCode == REQUEST_ENABLE_BT && resultCode == Activity.RESULT_CANCELED) {
            finish();
            return;
        }
        if (requestCode == REQUEST_ENABLE_BT && resultCode == Activity.RESULT_OK) {
            InitialBle();
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void ThisActivityInitial() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

        getSupportActionBar().setTitle(R.string.ble_conn_title);

        btnBleControl = (Button) findViewById(R.id.ble_conn_but_control);
        btnBleControl.setText(R.string.ble_conn_btn_scan);
        txtStatus = (TextView) findViewById(R.id.ble_conn_txt_status);

        lvScannedBleDevice = (ListView) findViewById(R.id.ble_conn_list_view_ble_devices);
        arrayScannedBleDevice = new ArrayList<>();
        lvBleDeviceAdapter = new LvBleDeviceAdapter(this, R.layout.list_view_ble_device_line, arrayScannedBleDevice);
        lvScannedBleDevice.setAdapter(lvBleDeviceAdapter);
    }

    private void InitialBle() {
        // Initializes a Bluetooth adapter.  For API level 18 and above, get a reference to
        // BluetoothAdapter through BluetoothManager.
        final BluetoothManager bluetoothManager =
                (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        mBluetoothAdapter = bluetoothManager.getAdapter();
        mBluetoothLeScanner = mBluetoothAdapter.getBluetoothLeScanner();
        mScanResults = new ArrayList<BluetoothDevice>();
        mBleScanCallback = new ThisBleScanCallback();
    }

    private void updateStatus(String messageStatus) {
        txtStatus.setText(messageStatus);
    }

    //---------------------------------------------------------------------------------------------
    //------------------------BLE Scan Device Code Region------------------------------------------

    private boolean hasPermissionsforBle() {
        //have Location Permissions granted?
        boolean hasLocationPermissions = checkSelfPermission(
                Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        if (!hasLocationPermissions) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_FINE_LOCATION);
            return false;
        }
        //Is BLE enabled?
        if ((mBluetoothAdapter == null) || (!mBluetoothAdapter.isEnabled())) {
            //Request BLE enable
            Intent enableBleIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBleIntent, REQUEST_ENABLE_BT);
            return false;
        }
        return true;
    }


    private void scanBleDevice(final boolean enable) {
        if (enable) {
            // Stops scanning after a pre-defined scan period.
            mHandler = new Handler();
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    mScanning = false;

                    mBluetoothLeScanner.stopScan(mBleScanCallback);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            btnBleControl.setText(R.string.ble_conn_btn_scan);
                            updateStatus(getString(R.string.ble_conn_status_scanning_completed));
                        }
                    });

                    Log.d(TAG, "number of device scanned: "+mScanResults.size());
                    Log.d(TAG, "BLE Scaning was stopped by timeout.");
                }
            }, SCAN_PERIOD);

            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    arrayScannedBleDevice.clear();
                    lvBleDeviceAdapter.notifyDataSetChanged();
                    btnBleControl.setText(R.string.ble_conn_btn_stop_scan);
                    updateStatus(getString(R.string.ble_conn_status_scanning));
                }
            });

            mScanResults.clear();
            List<ScanFilter> filters = new ArrayList<>();
            ScanSettings scanSettings = new ScanSettings.Builder()
                    .setScanMode(ScanSettings.SCAN_MODE_LOW_POWER).build();
            mBluetoothLeScanner.startScan(filters, scanSettings, mBleScanCallback);
            mScanning = true;
            Log.d(TAG, "BLE Scaning is started!");
        } else {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    btnBleControl.setText(R.string.ble_conn_btn_scan);
                    updateStatus(getString(R.string.ble_conn_status_scanning_stopped));
                }
            });
            mScanning = false;
            if (mHandler != null)  mHandler.removeCallbacksAndMessages(null);
            if (mBluetoothLeScanner != null) mBluetoothLeScanner.stopScan(mBleScanCallback);
            Log.d("BLE_SCAN", "BLE Scaning was stopped by command.");
        }
    }
                //------------BLE Internal Class-------------------------------------------

    private class ThisBleScanCallback extends ScanCallback {

        private void addScanResult(final ScanResult result) {
            final BluetoothDevice newDevice = result.getDevice();

            for (BluetoothDevice device : mScanResults) {
                if (device.getAddress().equals(newDevice.getAddress())) return;
            }

            mScanResults.add(result.getDevice());

            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    arrayScannedBleDevice.add(new LvBleDeviceLine(BleConnectionActivity.this,
                                                                    newDevice.getName(),
                                                                    newDevice.getAddress())
                                              );
                    lvBleDeviceAdapter.notifyDataSetChanged();
                }
            });

            Log.d(TAG, "new device: "
                                +result.getDevice().getName()
                                +", "+result.getDevice().getAddress());
        }

        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            super.onScanResult(callbackType, result);
            addScanResult(result);
        }

        @Override
        public void onBatchScanResults(List<ScanResult> results) {
            super.onBatchScanResults(results);
            for (ScanResult result : results) {
                addScanResult(result);
            }
        }

        @Override
        public void onScanFailed(int errorCode) {
            super.onScanFailed(errorCode);
            scanBleDevice(false);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(mBluetoothLeService, "Scanning was failed!", Toast.LENGTH_SHORT).show();
                }
            });

            Log.d(TAG, "BLE Scanning was failed! - "+errorCode);
        }
    }
    //----------------------------------------------------------------------------------------------
    //----------------------Broadcast Receiver for updating from BluetoothLeService-----------------
    private BroadcastReceiver mBleSrvBoardcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(BluetoothLeService.ACTION_GATT_CONNECTIVITY_CHANGED)) {
                if (mBluetoothLeService != null) {
                    if (mBluetoothLeService.getConnectionState() == BluetoothLeService.STATE_CONNECTED) {
                        mConnecting = false;
                        mScanResults.clear();
                        arrayScannedBleDevice.clear();
                        LvBleDeviceLine bleDeviceForLv;
                        bleDeviceForLv = new LvBleDeviceLine(BleConnectionActivity.this,
                                mBluetoothLeService.getBluetoothDeviceName(),
                                mBluetoothLeService.getBluetoothDeviceAddress());
                        arrayScannedBleDevice.add(bleDeviceForLv);

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                updateStatus(getString(R.string.ble_conn_status_connected_to));
                                lvBleDeviceAdapter.notifyDataSetChanged();
                                btnBleControl.setText(R.string.ble_conn_btn_disconnect);
                            }
                        });
                    } else if (mBluetoothLeService.getConnectionState() == BluetoothLeService.STATE_DISCONNECTED) {
                        mConnecting = false;
                        mScanResults.clear();
                        arrayScannedBleDevice.clear();
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                updateStatus(getString(R.string.ble_conn_status_disconnected));
                                lvBleDeviceAdapter.notifyDataSetChanged();
                                btnBleControl.setText(R.string.ble_conn_btn_scan);
                            }
                        });
                    }
                }
            }
        }
    };

    //----------------------------------------------------------------------------------------------
    //----------------------SERVICE CONNECTION TO BluetoothLeService--------------------------------

    private ServiceConnection mBleServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            mBluetoothLeService =
                    (BluetoothLeService) ((BluetoothLeService.LocalBinder)service).getService();

            if (!mBluetoothLeService.initialize()) {
                Log.e(TAG, "Unable to initialize Bluetooth");
                finish();
            }

            // Refresh activity.
            mScanResults.clear();
            arrayScannedBleDevice.clear();
            if (mBluetoothLeService.getConnectionState() == BluetoothLeService.STATE_CONNECTED ||
                mBluetoothLeService.getConnectionState() == BluetoothLeService.STATE_CONNECTING) {

                LvBleDeviceLine deviceForLv;
                deviceForLv = new LvBleDeviceLine(BleConnectionActivity.this,
                                                    mBluetoothLeService.getBluetoothDeviceName(),
                                                    mBluetoothLeService.getBluetoothDeviceAddress());
                arrayScannedBleDevice.add(deviceForLv);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (mBluetoothLeService.getConnectionState() == BluetoothLeService.STATE_CONNECTED) {
                            updateStatus(getString(R.string.ble_conn_status_connected_to));
                        } else {
                            updateStatus(getString(R.string.ble_conn_status_connecting_to));
                        }
                        lvBleDeviceAdapter.notifyDataSetChanged();
                        btnBleControl.setText(R.string.ble_conn_btn_disconnect);
                    }
                });
            } else {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        updateStatus(getString(R.string.welcome_short));
                        lvBleDeviceAdapter.notifyDataSetChanged();
                        btnBleControl.setText(R.string.ble_conn_btn_scan);
                    }
                });
            }

            InitialBle();

            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction(BluetoothLeService.ACTION_GATT_CONNECTIVITY_CHANGED);
            registerReceiver(mBleSrvBoardcastReceiver, intentFilter);
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mBluetoothLeService = null;
        }
    };

}